=== Jiniya Addons ===
Contributors: jiniyaaddons
Donate link: https://sasusit.com/jiniya-addons-donation/
Tags: jiniya addons, elementor, jiniya jiniya, jiniya jiniya member widget, jiniya widget
Requires at least: 6.0
Tested up to: 6.7.1
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

<ul>
  <li>Marquee Text</li>
  <li>Marquee Style Text</li>
</ul>

== Description ==

jiniya Addons is an elementor base widget which is working Marquee Effect for your website. 
Effect style is : Input Field text will Left to Right, Right to Left, Up to Down, Down to Up

== Frequently Asked Questions ==

= Can I use the plugin without Elementor Page Builder? =

No. You cannot use without Elementor since it’s an addon for Elementor.

= Does it work with any theme? =

Absolutely! It will work with any theme where Elementor works.

= Is there any shortcode to use it in a page or post ? =

No.

== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

= 0.5 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 0.5 =
This version fixes a security related bug.  Upgrade immediately.